<div class="rhea_thumb_wrapper rhea_classic_listing_slider">
    <ul class="slides">
        <?php
        global $news_grid_size;
            list_gallery_images( $news_grid_size );
        ?>
    </ul>
</div>
