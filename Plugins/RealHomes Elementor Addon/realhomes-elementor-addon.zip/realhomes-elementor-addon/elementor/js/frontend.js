/**
 * ERE Elementor Frontend JS
 */