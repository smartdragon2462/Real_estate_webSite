<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$theme_show_social_menu = $this->get_option( 'theme_show_social_menu', 'true' );
$theme_facebook_link    = $this->get_option( 'theme_facebook_link' );
$theme_twitter_link     = $this->get_option( 'theme_twitter_link' );
$theme_linkedin_link    = $this->get_option( 'theme_linkedin_link' );
$theme_instagram_link   = $this->get_option( 'theme_instagram_link' );
$theme_youtube_link     = $this->get_option( 'theme_youtube_link' );
$theme_pinterest_link   = $this->get_option( 'theme_pinterest_link' );
$theme_rss_link         = $this->get_option( 'theme_rss_link' );
$theme_skype_username   = $this->get_option( 'theme_skype_username' );

if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'inspiry_ere_settings' ) ) {
	update_option( 'theme_show_social_menu', $theme_show_social_menu );
	update_option( 'theme_facebook_link', $theme_facebook_link );
	update_option( 'theme_twitter_link', $theme_twitter_link );
	update_option( 'theme_linkedin_link', $theme_linkedin_link );
	update_option( 'theme_instagram_link', $theme_instagram_link );
	update_option( 'theme_youtube_link', $theme_youtube_link );
	update_option( 'theme_pinterest_link', $theme_pinterest_link );
	update_option( 'theme_rss_link', $theme_rss_link );
	update_option( 'theme_skype_username', $theme_skype_username );
	$this->notice();
}
?>
<div class="inspiry-ere-page-content">
    <form method="post" action="" novalidate="novalidate">
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row"><?php esc_html_e( 'Show or Hide Social Icons', 'easy-real-estate' ); ?></th>
                <td>
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php esc_html_e( 'Show or Hide Social Icons', 'easy-real-estate' ); ?></span></legend>
                        <label>
                            <input type="radio" name="theme_show_social_menu" value="true" <?php checked( $theme_show_social_menu, 'true' ) ?>>
                            <span><?php esc_html_e( 'Show', 'easy-real-estate' ); ?></span>
                        </label>
                        <br>
                        <label>
                            <input type="radio" name="theme_show_social_menu" value="false" <?php checked( $theme_show_social_menu, 'false' ) ?>>
                            <span><?php esc_html_e( 'Hide', 'easy-real-estate' ); ?></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="theme_facebook_link"><?php esc_html_e( 'Facebook URL', 'easy-real-estate' ); ?></label></th>
                <td><input name="theme_facebook_link" type="url" id="theme_facebook_link" value="<?php echo esc_url( $theme_facebook_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="theme_twitter_link"><?php esc_html_e( 'Twitter URL', 'easy-real-estate' ); ?></label></th>
                <td><input name="theme_twitter_link" type="url" id="theme_twitter_link" value="<?php echo esc_url( $theme_twitter_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="theme_linkedin_link"><?php esc_html_e( 'Linkedin URL', 'easy-real-estate' ); ?></label></th>
                <td><input name="theme_linkedin_link" type="url" id="theme_linkedin_link" value="<?php echo esc_url( $theme_linkedin_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="theme_instagram_link"><?php esc_html_e( 'Instagram URL', 'easy-real-estate' ); ?></label></th>
                <td><input name="theme_instagram_link" type="url" id="theme_instagram_link" value="<?php echo esc_url( $theme_instagram_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="theme_youtube_link"><?php esc_html_e( 'YouTube URL', 'easy-real-estate' ); ?></label></th>
                <td><input name="theme_youtube_link" type="url" id="theme_youtube_link" value="<?php echo esc_url( $theme_youtube_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="theme_pinterest_link"><?php esc_html_e( 'Pinterest URL', 'easy-real-estate' ); ?></label></th>
                <td><input name="theme_pinterest_link" type="url" id="theme_pinterest_link" value="<?php echo esc_url( $theme_pinterest_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="theme_rss_link"><?php esc_html_e( 'RSS URL', 'easy-real-estate' ); ?></label></th>
                <td><input name="theme_rss_link" type="url" id="theme_rss_link" value="<?php echo esc_url( $theme_rss_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="theme_skype_username"><?php esc_html_e( 'Skype Username', 'easy-real-estate' ); ?></label></th>
                <td><input name="theme_skype_username" type="text" id="theme_skype_username" value="<?php echo esc_attr( $theme_skype_username ); ?>" class="regular-text code"></td>
            </tr>
            </tbody>
        </table>
        <div class="submit">
            <?php wp_nonce_field('inspiry_ere_settings'); ?>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e( 'Save Changes', 'easy-real-estate' ); ?>">
        </div>
    </form>
</div>